//Mateus Martins Nicolussi - 831823
package Cadastro;

import java.util.ArrayList;
import java.util.List;

public class Imovel {
    private String nome;
    private String descricao;
    private String vlrvenda;
    private String tipo;
    private String categoria;

    public Imovel() {
    }

    public Imovel(String nome, String descricao, String vlrvenda,String tipo, String categoria) {
        this.nome = nome;
        this.descricao = descricao;
        this.vlrvenda = vlrvenda;
        this.tipo = tipo;
        this.categoria = categoria;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getVlrvenda() {
        return vlrvenda;
    }

    public void setVlrvenda(String vlrvenda) {
        this.vlrvenda = vlrvenda;
    }

    public List<String> getDados() {
        return imovel;
    }

    public void setImovel(List<String> imovel) {
        this.imovel = imovel;
    }
    List<String>imovel = new ArrayList<>();
    
}
